# Django-Polls

it's just the generic application.

